import numpy as np
from utils import *
from tqdm import tqdm
from seqeval.metrics import f1_score, accuracy_score, classification_report

class HMM:
    def __init__(self, char2idx_path):
        self.char2idx = load_dict(char2idx_path)
        self.tag2idx = {'O':0,'B-ADDRESS':1,'I-ADDRESS':2,'B-BOOK': 3, 'I-BOOK': 4, 'B-COM': 5, 'I-COM': 6, 'B-GAME': 7, 'I-GAME': 8, 'B-GOV': 9, 'I-GOV': 10, 
                        'B-MOVIE': 11,'I-MOVIE': 12,'B-NAME': 13,'I-NAME':14,'B-ORG':15,'I-ORG':16,'B-POS': 17, 'I-POS': 18, 'B-SCENE': 19, 'I-SCENE': 20}
        self.idx2tag = {v: k for k, v in self.tag2idx.items()}
        self.tag_size = len(self.tag2idx)
        self.vocab_size=len(self.char2idx)
        self.transition = np.zeros([self.tag_size,
                                    self.tag_size])
        self.emission = np.zeros([self.tag_size,
                                  self.vocab_size])
        self.pi = np.zeros(self.tag_size)
        self.epsilon = 1e-8

    def fit(self, train_dic_path):

        train_dic = load_data(train_dic_path)
        self.get_transition(train_dic)
        self.get_emission(train_dic)

        self.pi = np.log(self.pi)
        self.transition = np.log(self.transition)
        self.emission = np.log(self.emission)

    def get_emission(self, train_dic):

        for dic in tqdm(train_dic):
            for char, tag in zip(dic["text"], dic["label"]):
                self.emission[self.tag2idx[tag],
                              self.char2idx[char]] += 1
        self.emission[self.emission == 0] = self.epsilon
        self.emission /= np.sum(self.emission, axis=1, keepdims=True)

    def get_transition(self, train_dic):

        for dic in tqdm(train_dic):
            for i, tag in enumerate(dic["label"][:-1]):
                if i == 0:
                    self.pi[self.tag2idx[tag]] += 1
                curr_tag = self.tag2idx[tag]
                next_tag = self.tag2idx[dic["label"][i+1]]
                self.transition[curr_tag, next_tag] += 1
        self.transition[self.transition == 0] = self.epsilon
        self.transition /= np.sum(self.transition, axis=1, keepdims=True)
        self.pi[self.pi == 0] = self.epsilon
        self.pi /= np.sum(self.pi)

    def get_p(self, char):

        char_token = self.char2idx.get(char, 0)
        if char_token == 0:
            return np.log(np.ones(self.tag_size)/self.tag_size)
        return np.ravel(self.emission[:, char_token])

    def predict(self, text):
        best_tag_id = self.viterbi_decode(text)
        return [self.idx2tag[i] for i in best_tag_id]

    def viterbi_decode(self, text):
        seq_len = len(text)
        T1_table = np.zeros([seq_len, self.tag_size])
        T2_table = np.zeros([seq_len, self.tag_size])
        start_p = self.get_p(text[0])
        T1_table[0, :] = self.pi + start_p
        T2_table[0, :] = np.nan

        for i in range(1, seq_len):
            p_Obs_State = self.get_p(text[i])
            p_Obs_State = np.expand_dims(p_Obs_State, axis=0)
            prev_score = np.expand_dims(T1_table[i-1, :], axis=-1)
            curr_score = prev_score + self.transition + p_Obs_State
            T1_table[i, :] = np.max(curr_score, axis=0)
            T2_table[i, :] = np.argmax(curr_score, axis=0)
        best_tag_id = int(np.argmax(T1_table[-1, :]))
        best_tags = [best_tag_id, ]
        for i in range(seq_len-1, 0, -1):
            best_tag_id = int(T2_table[i, best_tag_id])
            best_tags.append(best_tag_id)
        return list(reversed(best_tags))
    def evaluation(self,dev_path):
        dev_dic=load_data(dev_path)
        y_true=[]
        y_pred=[]
        for dic in tqdm(dev_dic):
           y_true.append(dic['label'])
           y_pred.append(self.predict(dic['text']))
        print(len(y_true),len(y_pred))
        f1=f1_score(y_true,y_pred)
        acc=accuracy_score(y_true, y_pred)
        print(classification_report(y_true, y_pred))
        print('f1:{}  accuracy;{}'.format(f1,acc))

if __name__ == '__main__':
    model = HMM(char2idx_path="data/char2idx.txt")
    model.fit("data/train.txt")
    model.evaluation('data/dev.txt')