import utils
from tqdm import tqdm
   
def FMM(sen,max_len,dic):
    res=[]
    while len(sen)>0:
        cur_len=max_len
        while cur_len>1:
            try_word=sen[:cur_len]
            if utils.is_word(try_word,dic):
                res.append(try_word)
                sen=sen[cur_len:]
                break
            else:
                cur_len-=1
        if cur_len==1:
            try_word=sen[:cur_len]
            res.append(try_word)
            sen=sen[cur_len:]
    return res


def BMM(sen,max_len,dic):
    res=[]
    while len(sen)>0:
        cur_len=max_len
        while cur_len>1:
            try_word=sen[-1*cur_len:]
            if utils.is_word(try_word,dic):
                res.append(try_word)
                sen=sen[:-1*cur_len]
                break
            else:
                cur_len-=1
        if cur_len==1:
            try_word=sen[-1*cur_len:]
            res.append(try_word)
            sen=sen[:-1*cur_len]
    res.reverse()
    return res

def merge(BMM_result,FMM_result):
    final_result=[]
    for i in range(len(BMM_result)):
        b=BMM_result[i]
        f=FMM_result[i]
        if len(b)<len(f):
            final_result.append(b)
        elif len(f)<len(b):
            final_result.append(f)
        else:
            b_single=[len(i) for i in b].count(1)
            f_single=[len(i) for i in f].count(1)
            if b_single<f_single:
                final_result.append(b)
            else:
                final_result.append(f)
    return final_result

def BM(corpus,dic,max_len):
    BMM_result=[]
    FMM_result=[]
    for line in tqdm(corpus):
        FMM_result.append(FMM(line,max_len,dic))
        BMM_result.append(BMM(line,max_len,dic))
    final_result=merge(BMM_result,FMM_result)
    return final_result

if __name__=='__main__':
        
    dic_path='词典/pku_training_words.utf8'
    corpus_path='待分词文件/corpus.txt'
    dic=utils.get_dic(dic_path)
    corpus=utils.get_corpus(corpus_path)
    max_len=len(max(dic,key=lambda x:len(x)))
    
    final_result=BM(corpus,dic,max_len)
    R,P,F1=utils.evaluate(final_result)
    print("BM  R:{:.4f} P:{:.4f} F1:{:.4f}".format(R,P,F1))





    
