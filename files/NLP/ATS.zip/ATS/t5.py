model_checkpoint = 'sunhao666/chi-sum2'
from transformers import AutoTokenizer
from transformers import AutoModelForSeq2SeqLM
class t5:
    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained('uer/t5-base-chinese-cluecorpussmall')
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_checkpoint)

    def get_summary(self,text):
        input = self.tokenizer(text, max_length=128, truncation=True, return_tensors='pt')  # 对句子进行编码
        del input['token_type_ids']
        output = self.model.generate(
            **input,
            do_sample=True,  # 是否抽样
            num_beams=3,   # beam search
            bad_words_ids=[[101], [100]],  # bad_word_ids表示这些词不会出现在结果中
            # length_penalty=100,   # 长度的惩罚项
            max_length=100,     # 输出的最大长度
            repetition_penalty=5.0   # 重复的惩罚
        )
        summary = self.tokenizer.decode(output[0]).split('[SEP]')[0].replace('[CLS]', '').replace(' ', '')
        return summary
