label2short={'address':'ADDRESS','book':'BOOK','company':'COM','game':'GAME','government':'GOV','movie':'MOVIE','name':'NAME','organization':'ORG','position':"POS",'scene':'SCENE'}
def preprossing(in_path,out_path):
    f_in=open(in_path,'r',encoding='utf-8')
    f_out=open(out_path,'w',encoding='utf-8')
    for line in f_in.readlines():
        dic_in=eval(line)
        dic_out={}
        dic_out['text']=[char for char in dic_in['text']]
        dic_out['label']=['O' for i in range(len(dic_out['text']))]
        for label in dic_in['label']:
            for li in dic_in["label"][label].values():
                for sub_li in li:
                    first=True
                    for j in range(sub_li[0],sub_li[1]+1):
                        if first:
                            dic_out["label"][j]="B-"+label2short[label]
                            first=False
                        else:
                            dic_out["label"][j]="I-"+label2short[label]
        f_out.write(str(dic_out)+'\n')
    f_in.close()
    f_out.close()
def GetChar2ID(in_path,out_path):
    f_in=open(in_path,'r',encoding='utf-8')
    f_out=open(out_path,'w',encoding='utf-8')
    char2idx={}
    for line in f_in.readlines():
        dic_in=eval(line)
        for char in dic_in['text']:
            char2idx[char]=ord(char)
    sort=sorted(char2idx.values())
    id2idx={sort[i]:i for i in range(len(sort))}
    res={char:id2idx[char2idx[char]] for char in char2idx}
    
    f_out.write(str(res))
    f_in.close()
    f_out.close()

#preprossing('data/train.json','data/train.txt')
#preprossing('data/dev.json','data/dev.txt')
GetChar2ID('data/train.json','data/char2idx.txt')
