from tqdm import tqdm
import networkx as nx
import utils


def SPath(dic,corpus):
    result=[]
    for line in tqdm(corpus):
        G=nx.DiGraph()
        tuple2zi={}
        edges=[]
        for i,zi in enumerate(line):
            tuple2zi[(i,i+1)]=zi
            edges.append((i,i+1))
        G.add_edges_from(edges)
        
        new_edges=[]
        for word in dic:
            pos=line.find(word)
            while pos!=-1:
                s=pos
                e=pos+len(word)
                new_edges.append((s,e))
                pos=line.find(word,pos+1)
        G.add_edges_from(new_edges)
        sp=nx.shortest_path(G,0,max(G.nodes))
    
        re=[]
        for i in range(len(sp)-1):
            word=''
            for j in range(sp[i],sp[i+1]):
                word+=tuple2zi[(j,j+1)]
            re.append(word)
        result.append(re)
    return result

if __name__=="__main__":
    dic_path='词典/pku_training_words.utf8'
    corpus_path='待分词文件/corpus.txt'
    dic=utils.get_dic(dic_path)
    corpus=utils.get_corpus(corpus_path)
    
    
    re=SPath(dic,corpus)
    R,P,F1=utils.evaluate(re)
    print("SP R:{:.4f} P:{:.4f} F1:{:.4f}".format(R,P,F1))
