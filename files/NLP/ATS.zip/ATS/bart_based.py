import pandas as pd
from fastai.text.all import *
from transformers import *
from blurr.data.all import *
from blurr.modeling.all import *


class bart_based:
    def __init__(self):   
        df = pd.read_csv('数据集/train_data.csv',encoding='utf-8')
        df = df.dropna().reset_index()
        df['content'] = df['content'].apply(lambda x: x.replace('/',''))
        df['content'] = df['content'].apply(lambda x: x.replace('\xa0',''))
        self.df=df
    
        
    
        pretrained_model_name = "facebook/bart-large-cnn"
        hf_arch, hf_config, hf_tokenizer, hf_model = BLURR.get_hf_objects(pretrained_model_name, 
                                                                          model_cls=BartForConditionalGeneration)
        
        hf_batch_tfm = HF_Seq2SeqBeforeBatchTransform(hf_arch, hf_config, hf_tokenizer, hf_model, task='summarization',
        text_gen_kwargs={'max_length': 248,
         'min_length': 56,
         'do_sample': False,
         'early_stopping': True,
         'num_beams': 4,
         'temperature': 1.0,
         'top_k': 50,
         'top_p': 1.0,
         'repetition_penalty': 1.0,
         'bad_words_ids': None,
         'bos_token_id': 0,
         'pad_token_id': 1,
         'eos_token_id': 2,
         'length_penalty': 2.0,
         'no_repeat_ngram_size': 3,
         'encoder_no_repeat_ngram_size': 0,
         'num_return_sequences': 1,
         'decoder_start_token_id': 2,
         'use_cache': True,
         'num_beam_groups': 1,
         'diversity_penalty': 0.0,
         'output_attentions': False,
         'output_hidden_states': False,
         'output_scores': False,
         'return_dict_in_generate': False,
         'forced_bos_token_id': 0,
         'forced_eos_token_id': 2,
         'remove_invalid_values': False})
        
        blocks = (HF_Seq2SeqBlock(before_batch_tfm=hf_batch_tfm), noop)
        dblock = DataBlock(blocks=blocks, get_x=ColReader('content'), get_y=ColReader('title'), splitter=RandomSplitter())
        dls = dblock.dataloaders(articles, bs=2)
        seq2seq_metrics = {
                'rouge': {
                    'compute_kwargs': { 'rouge_types': ["rouge1", "rouge2", "rougeL"], 'use_stemmer': True },
                    'returns': ["rouge1", "rouge2", "rougeL"]
                },
                'bertscore': {
                    'compute_kwargs': { 'lang': 'fr' },
                    'returns': ["precision", "recall", "f1"]
                }
            }
        model = HF_BaseModelWrapper(hf_model)
        learn_cbs = [HF_BaseModelCallback]
        fit_cbs = [HF_Seq2SeqMetricsCallback(custom_metrics=seq2seq_metrics)]
        
        learn = Learner(dls, 
                        model,
                        opt_func=ranger,
                        loss_func=CrossEntropyLossFlat(),
                        cbs=learn_cbs,
                        splitter=partial(seq2seq_splitter, arch=hf_arch)).to_fp16()
        
        learn.create_opt() 
        learn.freeze()
        learn.fit_one_cycle(3, lr_max=3e-5, cbs=fit_cbs)
        self.learn=learn
        
    def get_summary(self,text):
        outputs = learn.blurr_generate(text, early_stopping=False, num_return_sequences=1)
    
        for idx, o in enumerate(outputs):
            print(f'=== Prediction {idx+1} ===\n{o}\n')
        
        return outputs