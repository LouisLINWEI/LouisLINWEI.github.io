import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd
from tqdm import tqdm
from torch import nn
import time
from torch.utils.data.dataset import random_split
from torchtext.data.functional import to_map_style_dataset
from sklearn.metrics import f1_score


class trainDataset(Dataset):
    def __init__(self):
        self.data=pd.read_csv("训练集/train_set.csv/train_set.csv",sep='\t')
    def __len__(self):
        return len(self.data)
    def __getitem__(self,idx):
        item=self.data.iloc[idx,:]
        label=item['label']
        text=item['text'].split(' ')
        text=[int(i) for i in text]
        return label,text

class testDataset(Dataset):
    def __init__(self):
        self.data=pd.read_csv("测试集/test.csv/test_a.csv",sep='\t')
    def __len__(self):
        return len(self.data)
    def __getitem__(self,idx):
        item=self.data.iloc[idx,:]
        text=item['text'].split(' ')
        text=[int(i) for i in text]
        return text 

def collate_batch(batch):
    label_list, text_list, offsets = [], [], [0]
    for (label, text) in batch:
         label_list.append(label)
         processed_text = torch.tensor(text, dtype=torch.int64)
         text_list.append(processed_text)
         offsets.append(processed_text.size(0))
    label_list = torch.tensor(label_list, dtype=torch.int64)
    offsets = torch.tensor(offsets[:-1]).cumsum(dim=0)
    text_list = torch.cat(text_list)
    return label_list.to(device), text_list.to(device), offsets.to(device)

def test_collate_batch(batch):
    text_list, offsets = [], [0]
    for  text in batch:
         processed_text = torch.tensor(text, dtype=torch.int64)
         text_list.append(processed_text)
         offsets.append(processed_text.size(0))
    offsets = torch.tensor(offsets[:-1]).cumsum(dim=0)
    text_list = torch.cat(text_list)
    return  text_list.to(device), offsets.to(device)


class TextClassificationModel(nn.Module):

    def __init__(self, vocab_size, embed_dim, num_class):
        super(TextClassificationModel, self).__init__()
        self.embedding = nn.EmbeddingBag(vocab_size, embed_dim, sparse=True)
        self.fc =  nn.Linear(embed_dim, num_class)
        self.init_weights()

    def init_weights(self):
        initrange = 0.5
        self.embedding.weight.data.uniform_(-initrange, initrange)
        self.fc.weight.data.uniform_(-initrange, initrange)
        self.fc.bias.data.zero_()

    def forward(self, text, offsets):
        embedded = self.embedding(text, offsets)
        return self.fc(embedded)
    



def train(dataloader):
    model.train()
    total_acc, total_count = 0, 0
    log_interval = 500
    start_time = time.time()

    for idx, (label, text, offsets) in enumerate(dataloader):
        optimizer.zero_grad()
        predicted_label = model(text, offsets)
        loss = criterion(predicted_label, label)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.1)
        optimizer.step()
        total_acc += (predicted_label.argmax(1) == label).sum().item()
        total_count += label.size(0)
        if idx % log_interval == 0 and idx > 0:
            elapsed = time.time() - start_time
            print('| epoch {:3d} | {:5d}/{:5d} batches '
                  '| accuracy {:8.3f}'.format(epoch, idx, len(dataloader),
                                              total_acc/total_count))
            total_acc, total_count = 0, 0
            start_time = time.time()
    torch.save(model,'my_model.pth')
def evaluate(dataloader):
    model.eval()
    total_acc, total_count = 0, 0
    y_true=[]
    y_pred=[]
    
    with torch.no_grad():
        for idx, (label, text, offsets) in enumerate(dataloader):
            predicted_label = model(text, offsets)
            loss = criterion(predicted_label, label)
            total_acc += (predicted_label.argmax(1) == label).sum().item()
            total_count += label.size(0)
            y_true.extend(label.cpu())
            y_pred.extend(predicted_label.argmax(1).cpu())
            
    f1=f1_score(y_true, y_pred, average='macro')
    return total_acc/total_count,f1

def test(dataloader):
    model.eval()
    res=[]
    
    with torch.no_grad():
        for idx, (text,offsets) in enumerate(dataloader):
            predicted_label = model(text, offsets)
            result=predicted_label.argmax(1).to('cpu').numpy()
            res.extend(result)
    df=pd.DataFrame()
    df['label']=res
    df.to_csv("test_result.csv")
    


num_class = 14
vocab_size = 7916
emsize = 64
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = TextClassificationModel(vocab_size, emsize, num_class).to(device)


EPOCHS = 5 
LR = 5  
BATCH_SIZE = 16 

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1.0, gamma=0.1)


total_accu = None
train_dataset = trainDataset()
test_dataset=testDataset()
num_train = int(len(train_dataset) * 0.95)
split_train_, split_valid_ = \
    random_split(train_dataset, [num_train, len(train_dataset) - num_train])

train_dataloader = DataLoader(split_train_, batch_size=BATCH_SIZE,
                              shuffle=True, collate_fn=collate_batch)
valid_dataloader = DataLoader(split_valid_, batch_size=BATCH_SIZE,
                              shuffle=True, collate_fn=collate_batch)
test_dataloader  = DataLoader(test_dataset,batch_size=BATCH_SIZE,
                              shuffle=False, collate_fn=test_collate_batch)

for epoch in range(1, EPOCHS + 1):
    epoch_start_time = time.time()
    train(train_dataloader)
    accu_val,f1 = evaluate(valid_dataloader)
    if total_accu is not None and total_accu > accu_val:
      scheduler.step()
    else:
        total_accu = accu_val
    print('-' * 59)
    print('| end of epoch {:3d} | time: {:5.2f}s | '
          'valid accuracy {:8.3f}, f1 {:.3f} '.format(epoch,time.time() - epoch_start_time,
                                            accu_val,f1))
    test(test_dataloader)

    






















