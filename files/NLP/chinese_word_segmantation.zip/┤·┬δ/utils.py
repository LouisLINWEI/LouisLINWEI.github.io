def get_dic(path):
    f=open(path,'r',encoding='utf-8')
    l=[]
    dic={}
    for line in f.readlines():
        l.append(line[:-1])
        dic[line[:-1]]=True
    f.close()
    return dic

def get_corpus(path):
    f=open(path,'r',encoding='utf-8')
    l=[]
    for line in f.readlines():
        if len(line)>1:
            l.append(line[:-1])
    f.close()
    return l

def res2ind(res):
    ind_res=[]
    for line in res:
        re=[]
        p=0
        for word in line:
            re.append(tuple(range(p,p+len(word))))
            p=p+len(word)
        ind_res.append(re)
    return ind_res

def ref2ind(ref_path):
    f=open(ref_path,'r',encoding='utf-8')
    res=[]
    for line in f.readlines():
        if len(line)>1:
            line_re=line[:-1].split()
            res.append(line_re)
    return res2ind(res)

def is_number(word):
    ch2ara={'零':0,'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10}
    for ch in ch2ara:
        word=word.replace(ch,str(ch2ara[ch]))
    return word.isdigit()

def is_word(try_word,dic):
    re=dic.get(try_word,False)
    if try_word[-1] in ['年',"月","日",'点','时','分','秒','万','十万','百万','千万','亿']:
        if is_number(try_word[:-1]):
            re=True
    if is_number(try_word):
        re=True
    return re

def evaluate(res,ref_path='分词对比文件/gold.txt'):
    pred=res2ind(res)
    gold=ref2ind(ref_path)
    both=0
    gold_total=sum([len(i) for i in gold])
    pred_total=sum([len(i) for i in pred])
    for i in range(len(pred)):
        gold_line=set(gold[i])
        pred_line=set(pred[i])
        both+=len(gold_line&pred_line)
    R=both/gold_total
    P=both/pred_total
    f1=2*P*R/(P+R)
    return R,P,f1


        

