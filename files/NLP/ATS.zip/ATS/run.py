from tqdm import tqdm
import utils
import tfidf
from t5 import t5
from bart_based import bart_based
from mt5 import mt5


def run_tfidf():
    f=open('数据集/test_data.json','r',encoding='utf-8')
    lines=f.readlines()
    f.close()
    
    datas=[]
    s_cur=''
    print('start loading data\n')
    for i in tqdm(range(1,len(lines)-1)):
        s_cur+=lines[i][:-1]
        if i%4==0 and i!=len(lines)-2:
            datas.append(eval(s_cur[:-1]))
            s_cur=''
        elif i%4==0:
            datas.append(eval(s_cur))
            s_cur=''
    
    print('start evaluating ')
    metric=['rouge_1','rouge_2','rouge_l','bleu']
    res={_:0 for _ in metric}
    evaluator=utils.get_evaluation_index()
    
    for data in tqdm(datas):
        label,text=data['title'],data['content']
        summarization=tfidf.overal(text)
        for _ in metric:
            res[_]+=eval('evaluator.get_{}(summarization,label)'.format(_))
    result={i:res[i]/len(datas) for i in metric}
    
    return result
result=run_tfidf()
print(result)


def run_t5():
    model=t5()
    f=open('数据集/test_data.json','r',encoding='utf-8')
    lines=f.readlines()
    f.close()
    
    datas=[]
    s_cur=''
    print('start loading data\n')
    for i in tqdm(range(1,len(lines)-1)):
        s_cur+=lines[i][:-1]
        if i%4==0 and i!=len(lines)-2:
            datas.append(eval(s_cur[:-1]))
            s_cur=''
        elif i%4==0:
            datas.append(eval(s_cur))
            s_cur=''
    
    print('start evaluating ')
    metric=['rouge_1','rouge_2','rouge_l','bleu']
    res={_:0 for _ in metric}
    evaluator=utils.get_evaluation_index()
    
    pbar=tqdm(datas)
    time=0
    for data in pbar:
        time+=1
        label,text=data['title'],data['content']
        summarization=model.get_summary(text)
        for _ in metric:
            res[_]+=eval('evaluator.get_{}(summarization,label)'.format(_))
        pbar.set_description(str({i:res[i]/time for i in res}))
    result={i:res[i]/len(datas) for i in metric}
    return result

# result=run_t5()

def run_bart():
    model=bart_based()
    f=open('数据集/test_data.json','r',encoding='utf-8')
    lines=f.readlines()
    f.close()
    
    datas=[]
    s_cur=''
    print('start loading data\n')
    for i in tqdm(range(1,len(lines)-1)):
        s_cur+=lines[i][:-1]
        if i%4==0 and i!=len(lines)-2:
            datas.append(eval(s_cur[:-1]))
            s_cur=''
        elif i%4==0:
            datas.append(eval(s_cur))
            s_cur=''
    
    print('start evaluating ')
    metric=['rouge_1','rouge_2','rouge_l','bleu']
    res={_:0 for _ in metric}
    evaluator=utils.get_evaluation_index()
    
    pbar=tqdm(datas)
    time=0
    for data in pbar:
        time+=1
        label,text=data['title'],data['content']
        summarization=model.get_summary(text)
        for _ in metric:
            res[_]+=eval('evaluator.get_{}(summarization,label)'.format(_))
        pbar.set_description(str({i:res[i]/time for i in res}))
    result={i:res[i]/len(datas) for i in metric}
    return result

# result=run_bart()


def run_mt5():
    model=mt5()
    f=open('数据集/test_data.json','r',encoding='utf-8')
    lines=f.readlines()
    f.close()
    
    datas=[]
    s_cur=''
    print('start loading data\n')
    for i in tqdm(range(1,len(lines)-1)):
        s_cur+=lines[i][:-1]
        if i%4==0 and i!=len(lines)-2:
            datas.append(eval(s_cur[:-1]))
            s_cur=''
        elif i%4==0:
            datas.append(eval(s_cur))
            s_cur=''
    
    print('start evaluating ')
    metric=['rouge_1','rouge_2','rouge_l','bleu']
    res={_:0 for _ in metric}
    evaluator=utils.get_evaluation_index()
    
    pbar=tqdm(datas)
    time=0
    for data in pbar:
        time+=1
        label,text=data['title'],data['content']
        summarization=model.get_summary(text)
        for _ in metric:
            res[_]+=eval('evaluator.get_{}(summarization,label)'.format(_))
        pbar.set_description(str({i:res[i]/time for i in res}))
    result={i:res[i]/len(datas) for i in metric}
    return result
    