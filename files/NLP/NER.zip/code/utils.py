def load_dict(path):
    f=open(path,'r',encoding='utf-8')
    dic=eval(f.read())
    f.close()
    return dic

def load_data(path):
    with open(path, "r", encoding="utf-8") as f:
        return [eval(i) for i in f.readlines()]
