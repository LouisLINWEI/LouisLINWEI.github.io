from wordcloud import WordCloud
import matplotlib.pyplot as plt
import utils
from BM import BM

stopwords = [line.strip() for line in open('停用词/stop_word.txt', 'r', encoding='utf-8')]

dic_path='词典/pku_training_words.utf8'
corpus_path='待分词文件/倚天屠龙记.txt'
dic=utils.get_dic(dic_path)
corpus=utils.get_corpus(corpus_path)
max_len=len(max(dic,key=lambda x:len(x)))


sentences=""
words=BM(corpus,dic,max_len)
for line in words:
    for word in line:
        if word in stopwords:
            continue
        sentences+=word+' '


w= WordCloud(background_color='white',width=2000,height=2000,max_words=200,font_path = "HGXK_CNKI.TTF",colormap='Spectral')
w=w.generate(sentences)
plt.imshow(w)
plt.axis('off')
plt.savefig('wordcloud.png',dpi=300, bbox_inches='tight')